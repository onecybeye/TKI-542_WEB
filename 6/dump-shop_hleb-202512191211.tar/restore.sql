--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE shop_hleb;
--
-- Name: shop_hleb; Type: DATABASE; Schema: -; Owner: blant
--

CREATE DATABASE shop_hleb WITH TEMPLATE = template0 ENCODING = 'SQL_ASCII' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE shop_hleb OWNER TO blant;

\connect shop_hleb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: help; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.help (
    id integer NOT NULL,
    text text NOT NULL
);


ALTER TABLE public.help OWNER TO blant;

--
-- Name: help_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.help_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.help_id_seq OWNER TO blant;

--
-- Name: help_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.help_id_seq OWNED BY public.help.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(10,2) NOT NULL
);


ALTER TABLE public.products OWNER TO blant;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO blant;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: shop_order_items; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.shop_order_items (
    id integer NOT NULL,
    shop_order_id integer,
    product_id integer,
    quantity integer NOT NULL
);


ALTER TABLE public.shop_order_items OWNER TO blant;

--
-- Name: shop_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.shop_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shop_order_items_id_seq OWNER TO blant;

--
-- Name: shop_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.shop_order_items_id_seq OWNED BY public.shop_order_items.id;


--
-- Name: shop_orders; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.shop_orders (
    id integer NOT NULL,
    shop_id integer,
    order_date date NOT NULL
);


ALTER TABLE public.shop_orders OWNER TO blant;

--
-- Name: shop_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.shop_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shop_orders_id_seq OWNER TO blant;

--
-- Name: shop_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.shop_orders_id_seq OWNED BY public.shop_orders.id;


--
-- Name: shops; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.shops (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.shops OWNER TO blant;

--
-- Name: shops_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.shops_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shops_id_seq OWNER TO blant;

--
-- Name: shops_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.shops_id_seq OWNED BY public.shops.id;


--
-- Name: supplier_order_items; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.supplier_order_items (
    id integer NOT NULL,
    supplier_order_id integer,
    product_id integer,
    quantity integer NOT NULL,
    amount numeric(10,2) NOT NULL
);


ALTER TABLE public.supplier_order_items OWNER TO blant;

--
-- Name: supplier_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.supplier_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_order_items_id_seq OWNER TO blant;

--
-- Name: supplier_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.supplier_order_items_id_seq OWNED BY public.supplier_order_items.id;


--
-- Name: supplier_orders; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.supplier_orders (
    id integer NOT NULL,
    supplier_id integer,
    order_date date NOT NULL
);


ALTER TABLE public.supplier_orders OWNER TO blant;

--
-- Name: supplier_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.supplier_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_orders_id_seq OWNER TO blant;

--
-- Name: supplier_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.supplier_orders_id_seq OWNED BY public.supplier_orders.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: blant
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.suppliers OWNER TO blant;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: blant
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_id_seq OWNER TO blant;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: blant
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: help id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.help ALTER COLUMN id SET DEFAULT nextval('public.help_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: shop_order_items id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shop_order_items ALTER COLUMN id SET DEFAULT nextval('public.shop_order_items_id_seq'::regclass);


--
-- Name: shop_orders id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shop_orders ALTER COLUMN id SET DEFAULT nextval('public.shop_orders_id_seq'::regclass);


--
-- Name: shops id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shops ALTER COLUMN id SET DEFAULT nextval('public.shops_id_seq'::regclass);


--
-- Name: supplier_order_items id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.supplier_order_items ALTER COLUMN id SET DEFAULT nextval('public.supplier_order_items_id_seq'::regclass);


--
-- Name: supplier_orders id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.supplier_orders ALTER COLUMN id SET DEFAULT nextval('public.supplier_orders_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Data for Name: help; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.help (id, text) FROM stdin;
\.
COPY public.help (id, text) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.products (id, name, price) FROM stdin;
\.
COPY public.products (id, name, price) FROM '$$PATH$$/3374.dat';

--
-- Data for Name: shop_order_items; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.shop_order_items (id, shop_order_id, product_id, quantity) FROM stdin;
\.
COPY public.shop_order_items (id, shop_order_id, product_id, quantity) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: shop_orders; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.shop_orders (id, shop_id, order_date) FROM stdin;
\.
COPY public.shop_orders (id, shop_id, order_date) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.shops (id, name) FROM stdin;
\.
COPY public.shops (id, name) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: supplier_order_items; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.supplier_order_items (id, supplier_order_id, product_id, quantity, amount) FROM stdin;
\.
COPY public.supplier_order_items (id, supplier_order_id, product_id, quantity, amount) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: supplier_orders; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.supplier_orders (id, supplier_id, order_date) FROM stdin;
\.
COPY public.supplier_orders (id, supplier_id, order_date) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: blant
--

COPY public.suppliers (id, name) FROM stdin;
\.
COPY public.suppliers (id, name) FROM '$$PATH$$/3376.dat';

--
-- Name: help_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.help_id_seq', 1, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.products_id_seq', 5, true);


--
-- Name: shop_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.shop_order_items_id_seq', 1, true);


--
-- Name: shop_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.shop_orders_id_seq', 1, true);


--
-- Name: shops_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.shops_id_seq', 3, true);


--
-- Name: supplier_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.supplier_order_items_id_seq', 1, true);


--
-- Name: supplier_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.supplier_orders_id_seq', 1, true);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: blant
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 2, true);


--
-- Name: help help_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.help
    ADD CONSTRAINT help_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: shop_order_items shop_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shop_order_items
    ADD CONSTRAINT shop_order_items_pkey PRIMARY KEY (id);


--
-- Name: shop_orders shop_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shop_orders
    ADD CONSTRAINT shop_orders_pkey PRIMARY KEY (id);


--
-- Name: shops shops_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_pkey PRIMARY KEY (id);


--
-- Name: supplier_order_items supplier_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.supplier_order_items
    ADD CONSTRAINT supplier_order_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_orders supplier_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.supplier_orders
    ADD CONSTRAINT supplier_orders_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: shop_order_items shop_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shop_order_items
    ADD CONSTRAINT shop_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: shop_order_items shop_order_items_shop_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shop_order_items
    ADD CONSTRAINT shop_order_items_shop_order_id_fkey FOREIGN KEY (shop_order_id) REFERENCES public.shop_orders(id) ON DELETE CASCADE;


--
-- Name: shop_orders shop_orders_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.shop_orders
    ADD CONSTRAINT shop_orders_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: supplier_order_items supplier_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.supplier_order_items
    ADD CONSTRAINT supplier_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: supplier_order_items supplier_order_items_supplier_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.supplier_order_items
    ADD CONSTRAINT supplier_order_items_supplier_order_id_fkey FOREIGN KEY (supplier_order_id) REFERENCES public.supplier_orders(id) ON DELETE CASCADE;


--
-- Name: supplier_orders supplier_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: blant
--

ALTER TABLE ONLY public.supplier_orders
    ADD CONSTRAINT supplier_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

